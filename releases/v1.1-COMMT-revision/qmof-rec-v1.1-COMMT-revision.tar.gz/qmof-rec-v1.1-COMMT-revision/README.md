# QMOF-Rec v1.1-COMMT-revision

This curated archive contains the authoritative final masked/diversity-aware protocol,
the reviewer-revision experiments, frozen machine-readable outputs, source metadata,
regression tests, and final consistency validation for COMMT-D-26-00255.

Environment: Python 3.9.6 with pinned packages in
`configs/reviewer_revision_requirements.txt`.

From the archive root, reproduce the original final protocol with:

```bash
python3 -m pip install -r configs/reviewer_revision_requirements.txt
python3 -m pytest -q backend/tests/test_missing_data_masks.py
python3 scripts/run_final_diversity_aware_masked_protocol.py \
  --config configs/final_diversity_aware_masked_protocol.json
```

The reviewer extension runner is included for exact inspection and reproduction:

```bash
python3 scripts/run_reviewer_revision.py
```

That extension performs the 1,750-run joint sensitivity grid, matched top-5 MMR,
differential-evolution comparator, true no-diversity ablation, runtime scaling, and
descriptor-level screening checks. Running it rewrites `artifacts/reviewer_revision`;
compare generated files to the included SHA-256 manifest.

The configuration metadata correction adds the eighth formula-coordinate name only.
`artifacts/presubmission_v2/configuration_metadata_validation.json` records 5,000
identical vector/mask checks, 50 identical ordered top-5 LEA lists, passing regression
tests, and unchanged frozen CSV hashes.

No trained GraphSAGE/GAT model, independent LLM-quality benchmark, adsorption
validation, experimental validation, or new DFT validation is part of this release.
